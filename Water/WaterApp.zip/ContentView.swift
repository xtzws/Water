//
//  ContentView.swift
//  Water
//
//  Created by Isaac Greene on 2024-01-01.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var hkvm: HealthKitViewModel
    @State private var dietaryWater: Double?
    @State private var alertShown = false
    @State private var userWaterAmountAdd: String = ""
    
    var body: some View {
        Image(systemName: "humidity.fill")
            .symbolEffect(.variableColor.cumulative.dimInactiveLayers.nonReversing)
            .imageScale(.large)
            .foregroundStyle(.blue)
        Text("The simplest water tracking app is on its way!")
        Text("Come back in a few days or so.")
        
        VStack {
            if hkvm.isAuthorized {
                VStack {
                    HStack {
                        Image(systemName: "drop.degreesign.fill")
                        Text("Water today")
                    }
                    if hkvm.userWaterAmount != "" {
                        Text("\(hkvm.userWaterAmount) ounces")
                            .fontWeight(.bold)
                    } else {
                        Text("0 ounces")
                            .fontWeight(.bold)
                    }
                    Button ("Add Water") {
                        alertShown = true
                    }
                    .buttonStyle(.bordered)
                    .alert("Please enter how many ounces of water you drank", isPresented: $alertShown) {
                        TextField("water in ounces", text: $userWaterAmountAdd)
                            .keyboardType(.numberPad)
                        Button ("Cancel", role: .cancel) {}
                        Button ("Add") {
                            hkvm.writeWater(amount: Double(userWaterAmountAdd)!)
                        }
                    }
                }
            } else {
                VStack {
                    Text("Please Authorize Health!")
                        .font(.title3)
                    
                    Button {
                        hkvm.healthRequest()
                    } label: {
                        Text("Authorize HealthKit")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    .frame(width: 320, height: 55)
                    .background(Color(.red))
                    .cornerRadius(10)
                }
            }
            
        }
        .padding()
        .onAppear {
            hkvm.readWaterTakenToday()
        }
    }
}

#Preview {
    ContentView()
}
